import java.io.Serializable;

public class Customer  implements Serializable{

	private static int  ID=0;
	
	private int customerID;
	private String firstname;
	private String lastname;
	private String street;
	private int houseNo;
	private String zipCode;
	private String city;
	private String country;
	private String birthdate;
	
	public Customer(String[] input) {
		
		firstname = input[1];
		lastname = input[2];
		street = input[3];
		houseNo = Integer.valueOf(input[4]);
		zipCode  =input[5];
		city = input[6];
		country = input[7];
		birthdate= input[8];
		
		if(input.length == 9) {
			customerID = ID++;
		}else {
			customerID = Integer.valueOf(input[9]);
		}
	
	}
	
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public int getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	
}
