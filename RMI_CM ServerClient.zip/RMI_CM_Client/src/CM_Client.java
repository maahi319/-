import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.Scanner;

public class CM_Client {
	
	
	
	public static void main(String[] args)  throws NotBoundException, IOException, SQLException {
		
		String input= null;
		Scanner sc = new Scanner(System.in);
		String name="//localhost/CustomerServer";
		ICustomerManagement icm =(ICustomerManagement) Naming.lookup(name);

		
		
		System.out.println("The following 7 commands are possible: ");
		System.out.println("\n\t (1) createCustomer;<FirstName>;<LastName>;<Street>;<HouseNo>;<ZipCode>;<City>;<Country>;<Birthdate>");
		System.out.println("\n\t (2) updateCustomer;<FirstName>;<LastName>;<Street>;<HouseNo>;<ZipCode>;<City>;<Country>;<Birthdate>;<CustomerID>");
		System.out.println("\n\t (3) deleteCustomer;<CustomerID>");
		System.out.println("\n\t (4) getAllCustomers");
		System.out.println("\n\t (5) getCustomer;<CustomerID>");
		System.out.println("\n\t (6) getAllCustomersByZipCode;<ZipCode>");
		System.out.println("\n\t (7) closeCustomerManager\n");
		
		
		do {
			System.out.print("Your Command: ");
			input = sc.next();
			
			if (input.split(";")[0].contentEquals("createCustomer")) {
				
				Customer a = new Customer(input.split(";"));		
				icm.createCustomer(a);
				System.out.println("Server:\t\tCreated succesfully.");

			}
			
			else if (input.split(";")[0].contentEquals("updateCustomer")) {
				Customer c = new Customer(input.split(";"));	
				
				if(icm.updateCustomer(c)==true) {
					System.out.println("Server:\t\tUpdated succesfully.");
				}
				else {
					System.out.println("Server:\t\tUpdate process failed.");
				}
			}
			
			else if (input.split(";")[0].contentEquals("deleteCustomer")) {
				if(icm.deleteCustomer(Integer.parseInt(input.split(";")[1]))) {
					System.out.println("Deleted succesfully.");
				}
				else {
				System.out.println("Server:\t\tDelete process failed.");
				}
			}
			
			else if (input.equals("getAllCustomers")) {
				Customer[] clist = icm.getAllCustomers();
				if (clist != null) {
					for(int i=0; i < clist.length ; i++) {
						System.out.println("\n\t\t("+ Integer.sum(i, 1) +".Customer)");
						printCustomer(clist[i]);
					}
					System.out.print("\n");
				} else {
					System.out.println("Server:\t\tNo Customers found!");
				}
			}
			
			else if (input.split(";")[0].contentEquals("getCustomer")) {
				Customer c = icm.getCustomer(Integer.parseInt(input.split(";")[1]));
				if(c != null) {
					printCustomer(c);
					System.out.print("\n");
				}
				else {
					System.out.println("Server:\t\tNo Customer found!");
				}
			}
			
			else if (input.split(";")[0].contentEquals("getAllCustomersByZipCode")) {
				Customer[] clist = icm.getAllCustomersByZipCode(input.split(";")[1]);
					if(clist != null) {
						for(int i=0; i < clist.length ; i++) {
							System.out.println("\n\t\t("+ (i+1) +".Customer)");
							printCustomer(clist[i]);
						}
						System.out.print("\n");
					} else {
						System.out.println("Server:\t\tNo Customers found!");
					}
			}
			
			else if(input.equals("closeCustomerManager")) {
				icm.closeCustomerManager();
			}
				
		} while (!(input.equals("closeCustomerManager")));
		sc.close();
	}
	
	public static void printCustomer (Customer x) {
		System.out.println("ID:\t\t " +x.getCustomerID());
		System.out.println("First Name:\t "+x.getFirstname());
		System.out.println("Last Name:\t "+x.getLastname());
		System.out.println("Street:\t\t "+x.getStreet());
		System.out.println("House No:\t "+x.getHouseNo());
		System.out.println("Zip Code:\t "+x.getZipCode());
		System.out.println("City:\t\t "+x.getCity());
		System.out.println("Country:\t "+x.getCountry());
		System.out.println("Birthdate:\t "+x.getBirthdate());
	}
	

}
