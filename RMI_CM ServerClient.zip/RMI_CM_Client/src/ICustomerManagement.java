import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;

public interface ICustomerManagement extends Remote, Serializable {

	public void initializeCustomerManager() throws IOException, ClassNotFoundException;

	public void closeCustomerManager()throws IOException;

	public void createCustomer(Customer input)throws RemoteException;

	public boolean updateCustomer(Customer input)throws RemoteException;

	public boolean deleteCustomer(int CustomerID)throws RemoteException;

	public Customer[] getAllCustomers()throws RemoteException;

	public Customer getCustomer(int CustomerID)throws RemoteException;

	public Customer[] getAllCustomersByZipCode(String zipCode)throws RemoteException;
	/*
	public void createTableDBCustomer() throws SQLException;

	public void createTableDBAddress() throws SQLException;
	
	public void createCustomerDB(Customer input) throws SQLException;
	
	public void deleteCustomerDB(Customer input) throws SQLException;
	
	public void updateCustomerDB(Customer input) throws SQLException;
	
	public void getCustomerDB(Customer input) throws SQLException;
	
	public void getAllCustomerDB(Customer input) throws SQLException;
	*/
}
