import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnect {
	
	private String dburl="jdbc:hsqldb:customerDB";
	private String user="abc";
	private String password="";
	private String driverName="org.hsqldb.jdbcDriver";
	
	private Connection con=null;
	
	public String getDburl() {
		return dburl;
	}
	public void setDburl(String dburl) {
		this.dburl = dburl;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public Connection getCon() {
		return con;
	}
	public void setCon(Connection con) {
		this.con = con;
	}
	
	public void shutdown() throws SQLException {

        Statement st = this.getCon().createStatement();

        st.execute("SHUTDOWN");
        this.getCon().close();
    }
	
	public void init() {
		
			try {
				Class.forName(this.getDriverName()).newInstance();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
			
			try {
				Connection conn =	DriverManager.getConnection(this.getDburl(), this.getUser(), this.getPassword());
				this.setCon(conn);
			
				} catch (SQLException ex) {
					System.out.println("SQLException: " + ex.getMessage());
					System.out.println("SQLState: " + ex.getSQLState());
					System.out.println("VendorError: " + ex.getErrorCode());
				}
	}
	
}
