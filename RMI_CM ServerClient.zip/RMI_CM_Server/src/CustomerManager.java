import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;

import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class CustomerManager extends UnicastRemoteObject implements ICustomerManagement{

	private ArrayList<Customer> customerList = new ArrayList<Customer>();
	
	protected CustomerManager() throws RemoteException, ClassNotFoundException {
		super();
		try {
			initializeCustomerManager();			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected CustomerManager(DBConnect dbcon) throws RemoteException, ClassNotFoundException, IOException {
		super();
		dbcon.init();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void initializeCustomerManager() throws IOException, ClassNotFoundException{
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("AllCustomers"));     
			if (br.readLine() == null) {
			    System.out.println("File is empty");
			}
			else {
				FileInputStream fis = new FileInputStream("AllCustomers");
				@SuppressWarnings("resource")
				ObjectInputStream ois = new ObjectInputStream(fis);
				customerList= (ArrayList<Customer>) ois.readObject();
			}
		} catch (FileNotFoundException f) {
			System.out.println("Server:\t\tThe Server is running for first time. A file named AllCustomers will be created at end of program.");
		}
		
	}
	
	@Override
	public void closeCustomerManager() throws IOException{
		System.out.println("All Customers are saved into following file: AllCustomers"); 
		FileOutputStream fos = new FileOutputStream("AllCustomers");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(customerList);
		oos.close();
		fos.close();
	}

	@Override
	public void createCustomer(Customer input) throws RemoteException{
		/*
		if((newID+1) > input.getID()) {
			input.setUpdateID(newID+1);
		}*/
		int biggestID = 0;
		for ( int i=0; i < customerList.size(); i++) {
			if(customerList.get(i).getCustomerID() > biggestID) {
				biggestID = customerList.get(i).getCustomerID();
			}
		}
		input.setCustomerID(biggestID+1);
		
		customerList.add(input);
	}
	
	@Override
	public boolean updateCustomer(Customer input) throws RemoteException{
		
		for(int i=0; i < customerList.size(); i++) {
			Customer c = customerList.get(i);
			if(c.getCustomerID() == input.getCustomerID()) {
		
				customerList.get(i).setFirstname(input.getFirstname());
				customerList.get(i).setLastname(input.getLastname());
				customerList.get(i).setStreet(input.getStreet());
				customerList.get(i).setHouseNo(input.getHouseNo());
				customerList.get(i).setZipCode(input.getZipCode());
				customerList.get(i).setCity(input.getCity());
				customerList.get(i).setCountry(input.getCountry());
				customerList.get(i).setBirthdate(input.getBirthdate());
				
			return true;				
			}
		}
		return false;
	}
	
	@Override
	public boolean deleteCustomer(int CustomerID) throws RemoteException{
		
		for(int i=0; i < customerList.size(); i++) {
			Customer c = customerList.get(i);
			if(c.getCustomerID() == CustomerID) {
				customerList.remove(c);
			return true;
			}
		}
		return false;
	}
	
	@Override
	public Customer[] getAllCustomers() throws RemoteException{ 
		Customer[] temp = new Customer[customerList.size()];
		 
		for(int i= 0; i< customerList.size();i++) {
			temp[i] = customerList.get(i);
		}
				 
		if (customerList.size() != 0) {
			return temp;
			}
		else {
			return null;
			}
	}
	
	@Override
	public Customer getCustomer(int CustomerID) throws RemoteException{

		for(int i=0; i < customerList.size(); i++) {
			Customer c = customerList.get(i);
			if(c.getCustomerID() == CustomerID) {
				return c;
			}
		}
	return null;
	}
	
	@Override
	public Customer[] getAllCustomersByZipCode(String zipCode) throws RemoteException{
		
		int newsize =0;
		int counter=0;
		Customer c= null;
		for(int i=0; i < customerList.size(); i++) {
			c = customerList.get(i);
			if(c.getZipCode().equals(zipCode)) {
				newsize++;
			}
		}
		Customer[] customerZip = new Customer[(newsize)];
		
		for(int i=0; i < customerList.size(); i++) {
			c = customerList.get(i);
			if(c.getZipCode().equals(zipCode)) {
				customerZip[counter] = c;
				counter++;
			}
		}
		if(customerList.size() != 0) {			
			return customerZip;
		}
		else {
			return null;
		}
		
	}
	
	public void createTableDBCustomer() throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="CREATE TABLE customer ("+ 
					"id INTEGER NOT NULL PRIMARY KEY," + 
					"firstname VARCHAR(256)," +
					"lastname VARCHAR(256)," +
					"birthdate VARCHAR(256))";
		stmt.executeUpdate(sql);
	    dbcon.shutdown();
	}
	
	public void createTableDBAddress() throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="CREATE TABLE address ("+
					"addressID INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT," +
					"street VARCHAR(256)," + 
					"houseNo INTEGER," +
					"zipCode VARCHAR(256)," +
					"city VARCHAR(256)," +
					"country VARCHAR(256),"+
					"FOREIGN KEY (id) references customer)";
		stmt.executeUpdate(sql);
	    dbcon.shutdown();
	}
	
	public void createCustomerDB(Customer input) throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="insert into customer (id,firstname,lastname,birthdate) values('"+input.getCustomerID()+"','"+input.getFirstname()+"','"+input.getLastname()+"','"+input.getBirthdate()+"')";            
		stmt.executeUpdate(sql);
		System.out.println(sql);
		System.exit(1);
		dbcon.shutdown();
		
		dbcon.init();
		stmt=dbcon.getCon().createStatement();
		sql="insert into address (street,houseNo,zipCode,city,country,id) values('"+input.getStreet()+"','"+input.getHouseNo()+"','"+input.getZipCode()+"','"+input.getCity()+"','"+input.getCountry()+"','"+input.getCustomerID()+"')";            
		stmt.executeUpdate(sql);
		System.out.println(sql);
		System.exit(1);
		dbcon.shutdown();
		
		}	
	
	public void deleteCustomerDB(Customer input) throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="delete from customer where id='"+input.getCustomerID()+"'";
		stmt.executeUpdate(sql);
		System.out.println(sql);
		System.out.println("erfolgreich gelöscht");
        dbcon.shutdown();
	}
	
	public void updateCustomerDB(Customer input) throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="update customer set firstname='"+input.getFirstname()+"', lastname='"+input.getLastname()+"', birthdate='"+input.getBirthdate()+"'where id="+input.getCustomerID() +"";
		stmt.executeUpdate(sql);
		System.out.println(sql);
        dbcon.shutdown();
        
        dbcon=new DBConnect();
		dbcon.init();
		stmt=dbcon.getCon().createStatement();
		sql="update customer set street='"+input.getStreet()+"', houseNo='"+input.getHouseNo()+"', zipCode='"+input.getZipCode()+"', city ='"+input.getCity()+"', country ='"+input.getCountry()+"'where id="+input.getCustomerID() +"";
		stmt.executeUpdate(sql);
		System.out.println(sql);
        dbcon.shutdown();
	}
	
	public void getCustomerDB(Customer input) throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="select id, firstname, lastname, birthdate from customer where id ="+input.getCustomerID();
		ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.print(rs.getString("ID")+" ");
			System.out.println(rs.getString("First Name")+" ");
			System.out.println(rs.getString("Last Name")+" ");
			System.out.println(rs.getString("Birthdate"));
			
		}
        dbcon.shutdown();
        
        dbcon=new DBConnect();
		dbcon.init();
		stmt=dbcon.getCon().createStatement();
		sql="select street, houseNo, zipCode, city, country from customer where id ="+input.getCustomerID();
		rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.print(rs.getString("Street")+" ");
			System.out.println(rs.getString("House No")+" ");
			System.out.println(rs.getString("Zip Code")+" ");
			System.out.println(rs.getString("City")+" ");
			System.out.println(rs.getString("Country"));
			
		}
        dbcon.shutdown();
	}
	
	public void getAllCustomerDB(Customer input) throws SQLException {
		DBConnect dbcon=new DBConnect();
		dbcon.init();
		Statement stmt=dbcon.getCon().createStatement();
		String sql="select id, firstname, lastname, birthdate from customer";
		ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.print(rs.getString("ID")+" ");
			System.out.println(rs.getString("First Name")+" ");
			System.out.println(rs.getString("Last Name")+" ");
			System.out.println(rs.getString("Birthdate"));
			
		}
        dbcon.shutdown();
        
        dbcon=new DBConnect();
		dbcon.init();
		stmt=dbcon.getCon().createStatement();
		sql="select street, houseNo, zipCode, city, country from address";
		rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.print(rs.getString("Street")+" ");
			System.out.println(rs.getString("House No")+" ");
			System.out.println(rs.getString("Zip Code")+" ");
			System.out.println(rs.getString("City")+" ");
			System.out.println(rs.getString("Country"));
			
		}
        dbcon.shutdown();
	}
	
}
