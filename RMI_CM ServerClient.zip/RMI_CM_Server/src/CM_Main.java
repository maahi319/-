import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class CM_Main {

	public static void main(String[] args) throws AlreadyBoundException, ClassNotFoundException, IOException {

		try {
			LocateRegistry.createRegistry(1099); // default port 1099 for RMI Registry
			String name="//localhost/CustomerServer";
			CustomerManager cm = new CustomerManager();
			
			/* DBConnect dbcon=new DBConnect();
			CustomerManager cm = new CustomerManager(dbcon); */
			Naming.bind(name, cm);
			System.out.println("Server:\t\tService started");
		} catch (RemoteException e) {
			e.printStackTrace();
			System.out.println("Server:\t\tCould not start registry.");
		}

	}
}

